const mysql = require('mysql2/promise');

const responseHeaders = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
};

exports.handler = async (event) => {
    console.log('Fetching products...');

    // Manejar preflight OPTIONS
    if (event.httpMethod === 'OPTIONS') {
        return { statusCode: 200, headers: responseHeaders, body: '' };
    }

    try {
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            port: Number(process.env.DB_PORT || 3306),
            database: process.env.DB_NAME,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            connectTimeout: 5000
        });

        const [rows] = await connection.execute('SELECT * FROM productos WHERE estado = "activo"');
        await connection.end();

        return {
            statusCode: 200,
            headers: responseHeaders,
            body: JSON.stringify(rows)
        };
    } catch (err) {
        console.error('ERROR:', err);
        return {
            statusCode: 500,
            headers: responseHeaders,
            body: JSON.stringify({
                error: 'Fallo al obtener productos',
                message: err.message
            })
        };
    }
};
